const API_URL = 'https://cfw-takehome.developers.workers.dev/api/variants'

addEventListener('fetch', event => {
  event.respondWith(handleRequest())
})

/**
 * Handle the request from the worker
 */
async function handleRequest() {
  const {variants} = await fetch(API_URL).then(res => res.json())
  return new Response(variants[Math.random() >= 0.5 ? 0 : 1], {
    headers: { 'content-type': 'text/plain' },
  })
}
